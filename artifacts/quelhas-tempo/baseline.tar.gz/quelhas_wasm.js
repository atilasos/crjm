/* @ts-self-types="./quelhas_wasm.d.ts" */

export class QuelhasEngine {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        QuelhasEngineFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_quelhasengine_free(ptr, 0);
    }
    clear_tt() {
        wasm.quelhasengine_clear_tt(this.__wbg_ptr);
    }
    /**
     * @param {number} tt_size_bits
     */
    constructor(tt_size_bits) {
        const ret = wasm.quelhasengine_new(tt_size_bits);
        this.__wbg_ptr = ret;
        QuelhasEngineFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} low_lo
     * @param {number} low_hi
     * @param {number} high_lo
     * @param {number} high_hi
     * @param {number} side
     * @param {number} time_budget_ms
     * @param {number} max_depth
     * @param {number} top_n
     * @param {number} score_delta
     * @returns {SearchResult}
     */
    search(low_lo, low_hi, high_lo, high_hi, side, time_budget_ms, max_depth, top_n, score_delta) {
        const ret = wasm.quelhasengine_search(this.__wbg_ptr, low_lo, low_hi, high_lo, high_hi, side, time_budget_ms, max_depth, top_n, score_delta);
        return SearchResult.__wrap(ret);
    }
}
if (Symbol.dispose) QuelhasEngine.prototype[Symbol.dispose] = QuelhasEngine.prototype.free;

export class SearchResult {
    static __wrap(ptr) {
        const obj = Object.create(SearchResult.prototype);
        obj.__wbg_ptr = ptr;
        SearchResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SearchResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_searchresult_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get best_move() {
        const ret = wasm.__wbg_get_searchresult_best_move(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get depth_reached() {
        const ret = wasm.__wbg_get_searchresult_depth_reached(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get elapsed_ms() {
        const ret = wasm.__wbg_get_searchresult_elapsed_ms(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get nodes_searched() {
        const ret = wasm.__wbg_get_searchresult_nodes_searched(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {number}
     */
    get score() {
        const ret = wasm.__wbg_get_searchresult_score(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get tt_hits() {
        const ret = wasm.__wbg_get_searchresult_tt_hits(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get tt_probes() {
        const ret = wasm.__wbg_get_searchresult_tt_probes(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {number} arg0
     */
    set best_move(arg0) {
        wasm.__wbg_set_searchresult_best_move(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set depth_reached(arg0) {
        wasm.__wbg_set_searchresult_depth_reached(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set elapsed_ms(arg0) {
        wasm.__wbg_set_searchresult_elapsed_ms(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set nodes_searched(arg0) {
        wasm.__wbg_set_searchresult_nodes_searched(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set score(arg0) {
        wasm.__wbg_set_searchresult_score(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set tt_hits(arg0) {
        wasm.__wbg_set_searchresult_tt_hits(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set tt_probes(arg0) {
        wasm.__wbg_set_searchresult_tt_probes(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) SearchResult.prototype[Symbol.dispose] = SearchResult.prototype.free;

export function init() {
    wasm.init();
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_throw_344f42d3211c4765: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_now_9d53435e04fcdf83: function() {
            const ret = Date.now();
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./quelhas_wasm_bg.js": import0,
    };
}

const QuelhasEngineFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_quelhasengine_free(ptr, 1));
const SearchResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_searchresult_free(ptr, 1));

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }


    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
